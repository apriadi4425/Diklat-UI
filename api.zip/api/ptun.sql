/*
SQLyog Professional v12.5.1 (64 bit)
MySQL - 10.3.16-MariaDB : Database - diklat-ptun
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `failed_jobs` */

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `failed_jobs` */

/*Table structure for table `konfig` */

DROP TABLE IF EXISTS `konfig`;

CREATE TABLE `konfig` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `nama_aplikasi` varchar(255) DEFAULT NULL,
  `singkatan_aplikasi` varchar(255) DEFAULT NULL,
  `nama_instansi` varchar(255) DEFAULT NULL,
  `kota` varchar(255) DEFAULT NULL,
  `singkatan_instansi` varchar(255) DEFAULT NULL,
  `nama_ketua` varchar(255) DEFAULT NULL,
  `nip_ketua` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `kode_pos` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telpon` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `konfig` */

insert  into `konfig`(`id`,`nama_aplikasi`,`singkatan_aplikasi`,`nama_instansi`,`kota`,`singkatan_instansi`,`nama_ketua`,`nip_ketua`,`alamat`,`kode_pos`,`email`,`telpon`,`website`,`fax`) values 
(1,'Aplikasi Jurnal Diklat','Adik','Pengadilan Tata Usaha Negara Banjarmasin','Banjarmasinx','PTUN BJM','BONNYARTI KALA LANDE, S.H., M.H.','19690323 199403 2 001','Jalan Brigjend H. Hasan Basri No. 32','70123','banjarmasin@ptun.org','(0511) 3300072, (0511)','www.ptun-banjarmasin.go.id','(0511) 3300072');

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `migrations` */

insert  into `migrations`(`id`,`migration`,`batch`) values 
(1,'2014_10_12_000000_create_users_table',1),
(2,'2014_10_12_100000_create_password_resets_table',1),
(3,'2019_08_19_000000_create_failed_jobs_table',1),
(4,'2019_12_14_000001_create_personal_access_tokens_table',1),
(5,'2021_02_03_041119_create_table_diklat',2),
(6,'2021_02_03_222015_create_table_surat_tugas',3),
(7,'2021_02_03_222845_create_table_peserta_diklat',4),
(8,'2021_02_05_070031_create_table_dokument_diklat',5),
(9,'2021_02_06_010942_create_table_halaman_pdf',6),
(10,'2021_02_06_105328_create_table_sertifikasi_peserta',7);

/*Table structure for table `password_resets` */

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `password_resets` */

/*Table structure for table `personal_access_tokens` */

DROP TABLE IF EXISTS `personal_access_tokens`;

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `personal_access_tokens` */

insert  into `personal_access_tokens`(`id`,`tokenable_type`,`tokenable_id`,`name`,`token`,`abilities`,`last_used_at`,`created_at`,`updated_at`) values 
(1,'App\\Models\\User',1,'my-app-token','2b0e2f9c24db6a169590bc9d28d0f9ba2f9e29f18ce42e13b75445799d445c56','[\"*\"]',NULL,'2021-02-01 22:32:40','2021-02-01 22:32:40'),
(2,'App\\Models\\User',1,'my-app-token','a1280cc0283181a8b50718b771977b10ccd7a1e950d3ea6d6f44b62d07abd835','[\"*\"]',NULL,'2021-02-02 20:47:38','2021-02-02 20:47:38'),
(3,'App\\Models\\User',1,'my-app-token','0c300817112396c991ec2f74674fb041bf28ae61f71a130f0b425411b4f16f04','[\"*\"]',NULL,'2021-02-02 21:05:10','2021-02-02 21:05:10'),
(4,'App\\Models\\User',1,'my-app-token','42b5df2ac2d3870fd3264a54b6b0635c887290bd91131d509a2291e0a3c0f627','[\"*\"]',NULL,'2021-02-02 21:05:29','2021-02-02 21:05:29'),
(5,'App\\Models\\User',1,'my-app-token','39ee5cb95c37d523a1871ebb0462872cf7eb2c91d20f8f6ca901156568172da1','[\"*\"]',NULL,'2021-02-02 21:06:19','2021-02-02 21:06:19'),
(6,'App\\Models\\User',1,'my-app-token','8a406e8c8adf476f95e7f5a6436233f29a2fb0828a2beac4f2853b61bbc1b2cf','[\"*\"]',NULL,'2021-02-02 21:06:34','2021-02-02 21:06:34'),
(7,'App\\Models\\User',1,'my-app-token','ceace5f6f4d4e49ff7c04e5f0d846cf0a0928b56d9d7687f7ae5326e48b33cd0','[\"*\"]',NULL,'2021-02-02 21:07:08','2021-02-02 21:07:08'),
(8,'App\\Models\\User',1,'my-app-token','a18f9d5273b8bb2d82fd337572ab6919e3f653241fbab70de25e989f7fbb03c9','[\"*\"]',NULL,'2021-02-02 21:07:12','2021-02-02 21:07:12'),
(9,'App\\Models\\User',1,'my-app-token','cf4c40738cd90c76e40f3878b7d6378294c2bbcf242fc3fb3e77eb2ed59237a1','[\"*\"]',NULL,'2021-02-02 21:16:18','2021-02-02 21:16:18'),
(10,'App\\Models\\User',1,'my-app-token','fa77353fa35990adff8cea8d61de45f75b2d5ddbe7ce4dd03eb52aa042997545','[\"*\"]',NULL,'2021-02-02 21:22:18','2021-02-02 21:22:18'),
(11,'App\\Models\\User',1,'my-app-token','87ba92073ec738d5ccad6c53e2cd91349c55dd767b689d103536a0c7820ce8d4','[\"*\"]',NULL,'2021-02-02 21:26:01','2021-02-02 21:26:01'),
(12,'App\\Models\\User',1,'my-app-token','54bac80d1a60b6354c01c87c0c9aae09866f45bdce3afff2dde417fed0ee4a0f','[\"*\"]',NULL,'2021-02-02 21:28:14','2021-02-02 21:28:14'),
(13,'App\\Models\\User',1,'my-app-token','6ded6b1b83d848964d4bfc5b1b8a9088138f2fba6eb0899ae67e4b12993c5c64','[\"*\"]','2021-02-02 22:56:02','2021-02-02 21:28:24','2021-02-02 22:56:02'),
(14,'App\\Models\\User',1,'my-app-token','3ec5880e5bcbff73a8ffe77a6b5eb0a2b04406cbcf3f1f5f7cc0f93858309f57','[\"*\"]','2021-02-02 22:58:42','2021-02-02 22:54:43','2021-02-02 22:58:42'),
(15,'App\\Models\\User',1,'my-app-token','07b40306372d82caf7b79f5b3888d88a2060ce03dfdb9f64e170d8299e3c8de3','[\"*\"]','2021-02-03 21:08:05','2021-02-02 22:56:05','2021-02-03 21:08:05'),
(16,'App\\Models\\User',1,'my-app-token','692765707103b91c66cf1ebceb3958d1f59c6150f578ef2dc5fdd43344cc3ab2','[\"*\"]','2021-02-03 21:20:24','2021-02-03 21:08:44','2021-02-03 21:20:24'),
(17,'App\\Models\\User',1,'my-app-token','01175c6a3232c10fbefc793cc393d20de558ee37ed6d01b246100901969eef53','[\"*\"]','2021-02-03 21:22:35','2021-02-03 21:21:01','2021-02-03 21:22:35'),
(18,'App\\Models\\User',1,'my-app-token','b53901fc634b4d39cf6905520d87fdbd823d05f63ab7bc2a6eb1a673f2a6b14f','[\"*\"]','2021-02-03 21:23:50','2021-02-03 21:23:41','2021-02-03 21:23:50'),
(19,'App\\Models\\User',1,'my-app-token','468bc311c4c5e7a3336d3b6be8fbcab4de2d83ea1d8c5a4045dd5a17cf3d07b0','[\"*\"]','2021-02-06 13:56:58','2021-02-03 21:24:18','2021-02-06 13:56:58'),
(20,'App\\Models\\User',1,'my-app-token','047bbad19905772f7a1636b1851076c367df513a006bcfb8abf37ed2f1e8422d','[\"*\"]','2021-02-06 13:57:44','2021-02-06 13:57:07','2021-02-06 13:57:44'),
(21,'App\\Models\\User',1,'my-app-token','d1f08258c8282428aaa76eb218d333c4f96f1e2caa0c004fe0ceddfa510e0756','[\"*\"]','2021-02-06 23:24:54','2021-02-06 13:57:49','2021-02-06 23:24:54'),
(22,'App\\Models\\User',1,'my-app-token','509df924f27c7e489eced336880e1496aac285af38cf9cb4e0f7e7ed2b26c07f','[\"*\"]','2021-02-07 05:31:03','2021-02-07 05:25:39','2021-02-07 05:31:03'),
(23,'App\\Models\\User',1,'my-app-token','9572451f720a9b1cfa7f9646d4cbb3c43ac6a0e61ed6ba17caf8d15a6c3d9df3','[\"*\"]','2021-02-07 08:25:33','2021-02-07 05:32:08','2021-02-07 08:25:33'),
(24,'App\\Models\\User',1,'my-app-token','2ede6762a39b8aa1ae5879e015bb913d84d7ac714f3352933eead6e073763428','[\"*\"]','2021-02-07 09:08:25','2021-02-07 08:33:14','2021-02-07 09:08:25'),
(25,'App\\Models\\User',5,'my-app-token','7cc2870b3af929c729c027cae90e42f1c9457bb78e5dad1c438e4a3b06a571a4','[\"*\"]','2021-02-07 09:12:04','2021-02-07 09:08:54','2021-02-07 09:12:04'),
(26,'App\\Models\\User',5,'my-app-token','b95da523f90bd6ca30fbf629ef9d727c10b59db99796cfe21eb07e5973ac8a3e','[\"*\"]','2021-02-07 09:08:56','2021-02-07 09:08:55','2021-02-07 09:08:56'),
(27,'App\\Models\\User',1,'my-app-token','99378f2d3fe966594a8041f39e3ad4ca127865e22e90ff955c47bda3d4f93547','[\"*\"]','2021-02-07 09:12:11','2021-02-07 09:12:08','2021-02-07 09:12:11'),
(28,'App\\Models\\User',1,'my-app-token','a06df39181d0488522e136aefdb06a5264604aea0196b0821860b5adc5785b37','[\"*\"]','2021-02-07 09:12:23','2021-02-07 09:12:23','2021-02-07 09:12:23'),
(29,'App\\Models\\User',5,'my-app-token','77c0b8ba196b3a4579be86076efb7aae92090bc3c641a22e2dd05ea32d2f66f8','[\"*\"]','2021-02-07 09:16:13','2021-02-07 09:12:35','2021-02-07 09:16:13'),
(30,'App\\Models\\User',1,'my-app-token','f64634844cbeec66ce1c82cd4431cd8085de8175868827bbd5b6a85298bf7ffd','[\"*\"]','2021-02-07 09:18:11','2021-02-07 09:16:16','2021-02-07 09:18:11'),
(31,'App\\Models\\User',1,'my-app-token','8760c69f2121864fe3d19569ba59a87bf48d1fcb4f3a6be6e6dabd0f5481bb9d','[\"*\"]','2021-02-07 09:18:40','2021-02-07 09:18:39','2021-02-07 09:18:40'),
(32,'App\\Models\\User',5,'my-app-token','056fa6945d7780783778b436683c1da3ba543ac9233c10bff1307f82d61d1a31','[\"*\"]','2021-02-07 09:24:34','2021-02-07 09:18:50','2021-02-07 09:24:34'),
(33,'App\\Models\\User',1,'my-app-token','79a3f7e47f81ace4cd72eff95f9ff7534ab42493f9382dd1c78ec6900f873fbb','[\"*\"]','2021-02-07 09:26:42','2021-02-07 09:26:40','2021-02-07 09:26:42'),
(34,'App\\Models\\User',1,'my-app-token','7c6461086914031b81c602c48903962966cc61a9f22b28e240762ce3da8642a3','[\"*\"]','2021-02-07 09:27:11','2021-02-07 09:27:11','2021-02-07 09:27:11'),
(35,'App\\Models\\User',1,'my-app-token','b7b14ffab1101c8e736b27821b10e9d2d0672d976b16d23d2c5ee9515bd88ba1','[\"*\"]','2021-02-07 09:32:19','2021-02-07 09:31:16','2021-02-07 09:32:19'),
(36,'App\\Models\\User',1,'my-app-token','b9e5e702724b3e35e4298092b36d029032044aca719ecd947ed535dbe467bc8c','[\"*\"]','2021-02-07 09:33:49','2021-02-07 09:32:23','2021-02-07 09:33:49'),
(37,'App\\Models\\User',5,'my-app-token','b8d9a2e18cd481c48f4822bffbe0c0d50730a2764ad50b65d5fd540b8d5c1267','[\"*\"]','2021-02-07 09:34:50','2021-02-07 09:33:59','2021-02-07 09:34:50'),
(38,'App\\Models\\User',1,'my-app-token','270015b904e9ceeb279895a281a444440a455c48074917d1f286359b990e551b','[\"*\"]','2021-02-07 09:36:03','2021-02-07 09:34:53','2021-02-07 09:36:03'),
(39,'App\\Models\\User',1,'my-app-token','b81f5d44161f5f050262cd235d684cf7cb8672cf873437921bfd2a106a233add','[\"*\"]','2021-02-07 09:36:07','2021-02-07 09:36:06','2021-02-07 09:36:07'),
(40,'App\\Models\\User',5,'my-app-token','fb814220c8373691f56246219fbc3095c5818228887b9a5b05325954032fd8f5','[\"*\"]','2021-02-07 09:36:17','2021-02-07 09:36:17','2021-02-07 09:36:17'),
(41,'App\\Models\\User',1,'my-app-token','46827f9ae2a857ea37995643122f541bb25fa8db1af5499930173e715f32d41f','[\"*\"]','2021-02-07 09:36:22','2021-02-07 09:36:22','2021-02-07 09:36:22'),
(42,'App\\Models\\User',5,'my-app-token','faafdec222248e35884e5a62e680c04bd619d94b334b4fb8f1efcf3ff0c33b47','[\"*\"]','2021-02-07 09:38:13','2021-02-07 09:36:30','2021-02-07 09:38:13'),
(43,'App\\Models\\User',1,'my-app-token','d4b3a6f9b48350cb4cb0fbe5cfd92c272799a684fd91e0aaa9f343f2f8431530','[\"*\"]','2021-02-07 09:38:20','2021-02-07 09:38:18','2021-02-07 09:38:20'),
(44,'App\\Models\\User',5,'my-app-token','3018117e1b0a3c34d006cb631ff674fc1f913783f4f0c119856fca239d1e5f60','[\"*\"]','2021-02-07 09:53:39','2021-02-07 09:38:31','2021-02-07 09:53:39'),
(45,'App\\Models\\User',3,'my-app-token','6bef3914520140a018da6597c5f8680aecf2f064bd3cd5e225322fbbf4c552da','[\"*\"]','2021-02-07 09:54:23','2021-02-07 09:53:58','2021-02-07 09:54:23'),
(46,'App\\Models\\User',1,'my-app-token','42392d60bfeb4fd4ad1ed390c9fd3e4e6fc7259b27f3a2cca37ec0b48679403a','[\"*\"]','2021-02-07 09:54:33','2021-02-07 09:54:27','2021-02-07 09:54:33'),
(47,'App\\Models\\User',3,'my-app-token','b654693b597c27a2f6324552337f5a4a3f16e0e16815e068c6aa7d0424d19266','[\"*\"]','2021-02-07 09:55:20','2021-02-07 09:54:52','2021-02-07 09:55:20'),
(48,'App\\Models\\User',5,'my-app-token','39351b0313cac6df114c773cf9c5d1c72a25b2fca26dc4400b1417f5702b18c0','[\"*\"]','2021-02-07 10:32:56','2021-02-07 09:55:32','2021-02-07 10:32:56'),
(49,'App\\Models\\User',5,'my-app-token','f84b83fccfa3e7b7944fa7e3d89f0f29832fc3af94e5ba8cb40cdef6d897e275','[\"*\"]','2021-02-07 10:33:59','2021-02-07 10:33:14','2021-02-07 10:33:59'),
(50,'App\\Models\\User',5,'my-app-token','4d935b6dbcdce574472765303737b4275e89728cec4c9746a8dea7e121b63462','[\"*\"]','2021-02-07 10:35:21','2021-02-07 10:35:06','2021-02-07 10:35:21'),
(51,'App\\Models\\User',1,'my-app-token','8e04de992c749317e81cf108a3f69d272b6c9fb48609d118e480c1fa03b7caff','[\"*\"]','2021-02-07 10:35:27','2021-02-07 10:35:27','2021-02-07 10:35:27'),
(52,'App\\Models\\User',5,'my-app-token','52d6e9535818f320c45b5b975416f4a8bdd24706c7b4f3305f9415159324731a','[\"*\"]','2021-02-07 10:35:40','2021-02-07 10:35:40','2021-02-07 10:35:40'),
(53,'App\\Models\\User',1,'my-app-token','93def9252692781050382ee4144a35880feafc019ab28b30c0f32210b6857fcc','[\"*\"]','2021-02-07 10:36:47','2021-02-07 10:35:44','2021-02-07 10:36:47'),
(54,'App\\Models\\User',1,'my-app-token','1272cf2ed45ca8e4c51645a10ed21e86311e2346dca786bd11d95bb82f7a6ece','[\"*\"]','2021-02-07 12:05:10','2021-02-07 10:37:13','2021-02-07 12:05:10'),
(55,'App\\Models\\User',1,'my-app-token','383a4593e248584c981091995c24fe815187f04d5f79f37dc0ad5d137d3d180f','[\"*\"]','2021-02-15 11:27:12','2021-02-15 11:26:16','2021-02-15 11:27:12'),
(56,'App\\Models\\User',1,'my-app-token','4330f21e57689e85dfd8d3c0bfb30f533afaaf26754b40ffe71bc94c975421ee','[\"*\"]','2021-02-15 11:29:36','2021-02-15 11:27:31','2021-02-15 11:29:36');

/*Table structure for table `table_diklat` */

DROP TABLE IF EXISTS `table_diklat`;

CREATE TABLE `table_diklat` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama_diklat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asal_surat_undangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `perihal_undangan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor_surat_undangan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_surat_undangan` date NOT NULL,
  `tempat_acara` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_awal_acara` date NOT NULL,
  `tanggal_akhir_acara` date NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `table_diklat` */

insert  into `table_diklat`(`id`,`nama_diklat`,`asal_surat_undangan`,`perihal_undangan`,`nomor_surat_undangan`,`tanggal_surat_undangan`,`tempat_acara`,`tanggal_awal_acara`,`tanggal_akhir_acara`,`slug`,`created_at`,`updated_at`) values 
(5,'Online Preparation For The Toefl Kelas 2','Kepala Badan Litbang Diklat Hukum dan Peradilan MARI','Pemanggilan Peserta Pelatihan Online Preparation For The Toefl Kelas 1 s.d 2 dari Tempat Tugas Tahun 2021,','22/Bld/S/1/2021','2021-01-14','Kantor PTUN Banjarmasin Jl. Brigjend H. Hasan Basri No. 32 Banjarmasin','2021-01-18','2021-02-26','eyJpdiI6Imc5QUJ3L3BlMEVFQkx1ZStnSEtRSWc9PSIsInZhbHVlIjoiQXBBdW11bjZMTGlOekZZZGxCNyt3d0pLTWw2WmZXZnFEQU9GOW9WUkh6WnBjSGlYN21wbHdxbDlrVUdGOXllYiIsIm1hYyI6ImVhZTMyZWJhZDg0ZTJkNjMwNjdkZjRiMjA4MTI5MDY2NTdjYWNjMDYyMzVlOTcyN2VhMzljZWQyZDk4ZGRmZDkifQ==','2021-02-05 03:07:44','2021-02-05 03:07:44'),
(8,'Diklat Makan Bersama dengan','Kepala Badan Litbang Diklat Hukum dan Peradilan MARI','tes','W15-A1-20.01.02','2021-02-01','PTA Banjarmasin','2021-02-01','2021-02-13','eyJpdiI6IjIya1JLblFxYkNNd2hRTlNNcGg5emc9PSIsInZhbHVlIjoiYU1vMjJrdDh3M1NrZHRJVDBORGt1UkNORndBU21zbnJxQjVMb1VqZ2hlaGxNbWNLLzlkbXVuRVZmdXNscWdUZSIsIm1hYyI6ImVkMDlkNzcxMTJkZTk0YWNjN2ExMDQ2OGVkMmM2YjI4NGUzZGY4OTUwZTA2ZDc5Y2M2N2ZiMWQ4M2IzYTBjZDcifQ==','2021-02-06 06:22:47','2021-02-06 06:22:47');

/*Table structure for table `table_dokument_diklat` */

DROP TABLE IF EXISTS `table_dokument_diklat`;

CREATE TABLE `table_dokument_diklat` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_diklat` bigint(20) unsigned NOT NULL,
  `tipe` int(5) DEFAULT NULL,
  `path_gambar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extensi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `table_dokument_diklat_id_diklat_foreign` (`id_diklat`),
  CONSTRAINT `table_dokument_diklat_id_diklat_foreign` FOREIGN KEY (`id_diklat`) REFERENCES `table_diklat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `table_dokument_diklat` */

insert  into `table_dokument_diklat`(`id`,`id_diklat`,`tipe`,`path_gambar`,`path_url`,`nama_file`,`slug`,`extensi`,`created_at`,`updated_at`) values 
(54,8,3,'8/1-8-sertifikat-plagiasi-setelah-edit-cuy.png','8-sertifikat-plagiasi-setelah-edit-cuy-1612619519.pdf','sertifikat plagiasi setelah edit cuy.pdf','8-sertifikat-plagiasi-setelah-edit-cuy.pdf','pdf','2021-02-06 13:52:03','2021-02-06 13:52:03');

/*Table structure for table `table_halaman_pdf` */

DROP TABLE IF EXISTS `table_halaman_pdf`;

CREATE TABLE `table_halaman_pdf` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_dokument` int(11) NOT NULL,
  `tipe` int(11) DEFAULT NULL,
  `path_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor_urut` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `table_halaman_pdf` */

insert  into `table_halaman_pdf`(`id`,`id_dokument`,`tipe`,`path_image`,`nomor_urut`,`created_at`,`updated_at`) values 
(9,28,1,'5/1-5-SK-Tim-Satgas-TI-Laskar-Banua-Tahun-2019.png',1,'2021-02-06 02:17:55','2021-02-06 02:17:55'),
(10,28,1,'5/2-5-SK-Tim-Satgas-TI-Laskar-Banua-Tahun-2019.png',2,'2021-02-06 02:17:55','2021-02-06 02:17:55'),
(11,28,1,'5/3-5-SK-Tim-Satgas-TI-Laskar-Banua-Tahun-2019.png',3,'2021-02-06 02:17:55','2021-02-06 02:17:55'),
(12,28,1,'5/4-5-SK-Tim-Satgas-TI-Laskar-Banua-Tahun-2019.png',4,'2021-02-06 02:17:55','2021-02-06 02:17:55'),
(13,29,1,'5/1-5-Cover.png',1,'2021-02-06 02:59:25','2021-02-06 02:59:25'),
(14,29,1,'5/2-5-Cover.png',2,'2021-02-06 02:59:25','2021-02-06 02:59:25'),
(15,30,1,'6/1-6-1a-Skripsi-Cover-word-tanpa-ttd.png',1,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(16,30,1,'6/2-6-1a-Skripsi-Cover-word-tanpa-ttd.png',2,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(17,30,1,'6/3-6-1a-Skripsi-Cover-word-tanpa-ttd.png',3,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(18,30,1,'6/4-6-1a-Skripsi-Cover-word-tanpa-ttd.png',4,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(19,30,1,'6/5-6-1a-Skripsi-Cover-word-tanpa-ttd.png',5,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(20,30,1,'6/6-6-1a-Skripsi-Cover-word-tanpa-ttd.png',6,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(21,30,1,'6/7-6-1a-Skripsi-Cover-word-tanpa-ttd.png',7,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(22,30,1,'6/8-6-1a-Skripsi-Cover-word-tanpa-ttd.png',8,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(23,30,1,'6/9-6-1a-Skripsi-Cover-word-tanpa-ttd.png',9,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(24,30,1,'6/10-6-1a-Skripsi-Cover-word-tanpa-ttd.png',10,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(25,30,1,'6/11-6-1a-Skripsi-Cover-word-tanpa-ttd.png',11,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(26,30,1,'6/12-6-1a-Skripsi-Cover-word-tanpa-ttd.png',12,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(27,30,1,'6/13-6-1a-Skripsi-Cover-word-tanpa-ttd.png',13,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(28,30,1,'6/14-6-1a-Skripsi-Cover-word-tanpa-ttd.png',14,'2021-02-06 03:16:02','2021-02-06 03:16:02'),
(29,38,3,'6/1-6-Sertifikat-plagiasi-Feni-Apriyanti-E1D314011.png',1,'2021-02-06 04:55:35','2021-02-06 04:55:35'),
(30,39,3,'7/1-7-sertifikat-plagiasi-setelah-edit-cuy.png',1,'2021-02-06 05:55:31','2021-02-06 05:55:31'),
(31,40,3,'8/1-8-sertifikat-plagiasi-setelah-edit-cuy.png',1,'2021-02-06 08:44:09','2021-02-06 08:44:09'),
(32,47,3,'8/1-8-sertifikat-plagiasi-setelah-edit-cuy.png',1,'2021-02-06 11:50:14','2021-02-06 11:50:14'),
(33,48,3,'8/1-8-sertifikat-plagiasi-setelah-edit-cuy.png',1,'2021-02-06 11:58:19','2021-02-06 11:58:19'),
(34,49,3,'8/1-8-Cover.png',1,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(35,49,3,'8/2-8-Cover.png',2,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(36,49,3,'8/3-8-Cover.png',3,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(37,49,3,'8/4-8-Cover.png',4,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(38,49,3,'8/5-8-Cover.png',5,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(39,49,3,'8/6-8-Cover.png',6,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(40,49,3,'8/7-8-Cover.png',7,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(41,49,3,'8/8-8-Cover.png',8,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(42,49,3,'8/9-8-Cover.png',9,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(43,49,3,'8/10-8-Cover.png',10,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(44,49,3,'8/11-8-Cover.png',11,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(45,49,3,'8/12-8-Cover.png',12,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(46,49,3,'8/13-8-Cover.png',13,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(47,49,3,'8/14-8-Cover.png',14,'2021-02-06 11:58:59','2021-02-06 11:58:59'),
(48,50,3,'8/1-8-sertifikat-plagiasi-setelah-edit-cuy.png',1,'2021-02-06 11:59:47','2021-02-06 11:59:47'),
(49,51,1,'5/1-5-Cover.png',1,'2021-02-06 12:00:54','2021-02-06 12:00:54'),
(50,51,1,'5/2-5-Cover.png',2,'2021-02-06 12:00:54','2021-02-06 12:00:54'),
(51,52,3,'5/1-5-sertifikat-plagiasi-setelah-edit-cuy.png',1,'2021-02-06 12:01:28','2021-02-06 12:01:28'),
(52,53,3,'8/1-8-sertifikat-plagiasi-setelah-edit-cuy.png',1,'2021-02-06 12:55:42','2021-02-06 12:55:42'),
(53,54,3,'8/1-8-sertifikat-plagiasi-setelah-edit-cuy.png',1,'2021-02-06 13:52:03','2021-02-06 13:52:03');

/*Table structure for table `table_peserta_diklat` */

DROP TABLE IF EXISTS `table_peserta_diklat`;

CREATE TABLE `table_peserta_diklat` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_diklat` bigint(20) unsigned NOT NULL,
  `id_surat_tugas` bigint(20) unsigned NOT NULL,
  `id_user` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `table_peserta_diklat_id_diklat_foreign` (`id_diklat`),
  KEY `table_peserta_diklat_id_surat_tugas_foreign` (`id_surat_tugas`),
  KEY `table_peserta_diklat_id_user_foreign` (`id_user`),
  CONSTRAINT `table_peserta_diklat_id_diklat_foreign` FOREIGN KEY (`id_diklat`) REFERENCES `table_diklat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `table_peserta_diklat_id_surat_tugas_foreign` FOREIGN KEY (`id_surat_tugas`) REFERENCES `table_surat_tugas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `table_peserta_diklat_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `table_peserta_diklat` */

insert  into `table_peserta_diklat`(`id`,`id_diklat`,`id_surat_tugas`,`id_user`,`created_at`,`updated_at`) values 
(61,5,11,3,'2021-02-05 03:14:02','2021-02-05 03:14:02'),
(62,5,11,4,'2021-02-05 03:14:02','2021-02-05 03:14:02'),
(63,5,11,5,'2021-02-05 03:14:02','2021-02-05 03:14:02'),
(70,8,15,4,'2021-02-07 05:30:30','2021-02-07 05:30:30'),
(71,8,15,5,'2021-02-07 05:30:30','2021-02-07 05:30:30');

/*Table structure for table `table_sertifikasi_peserta` */

DROP TABLE IF EXISTS `table_sertifikasi_peserta`;

CREATE TABLE `table_sertifikasi_peserta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_diklat` bigint(20) unsigned NOT NULL,
  `id_dokument` bigint(20) unsigned NOT NULL,
  `id_user` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `table_sertifikasi_peserta_id_dokument_foreign` (`id_dokument`),
  KEY `table_sertifikasi_peserta_id_user_foreign` (`id_user`),
  KEY `id_diklat` (`id_diklat`),
  CONSTRAINT `table_sertifikasi_peserta_ibfk_1` FOREIGN KEY (`id_diklat`) REFERENCES `table_diklat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `table_sertifikasi_peserta_id_dokument_foreign` FOREIGN KEY (`id_dokument`) REFERENCES `table_dokument_diklat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `table_sertifikasi_peserta_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `table_sertifikasi_peserta` */

insert  into `table_sertifikasi_peserta`(`id`,`id_diklat`,`id_dokument`,`id_user`,`created_at`,`updated_at`) values 
(6,8,54,5,'2021-02-06 13:52:03','2021-02-06 13:52:03');

/*Table structure for table `table_surat_tugas` */

DROP TABLE IF EXISTS `table_surat_tugas`;

CREATE TABLE `table_surat_tugas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_diklat` bigint(20) unsigned NOT NULL,
  `nomor_surat_tugas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_surat_tugas` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `table_surat_tugas_id_diklat_foreign` (`id_diklat`),
  CONSTRAINT `table_surat_tugas_id_diklat_foreign` FOREIGN KEY (`id_diklat`) REFERENCES `table_diklat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `table_surat_tugas` */

insert  into `table_surat_tugas`(`id`,`id_diklat`,`nomor_surat_tugas`,`tanggal_surat_tugas`,`created_at`,`updated_at`) values 
(11,5,'W2-TUN3/97/KP./I/2021','2021-01-18','2021-02-05 03:09:06','2021-02-05 03:09:06'),
(15,8,'W2-TUN3/94/KP./I/2021','2021-02-01','2021-02-06 08:37:25','2021-02-06 08:37:25');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `otoritas` int(5) DEFAULT 2,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pangkat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `golongan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jabatan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`otoritas`,`name`,`email`,`nip`,`pangkat`,`golongan`,`jabatan`,`email_verified_at`,`password`,`remember_token`,`created_at`,`updated_at`) values 
(1,1,'Apriadi','apripeni15@gmail.com','54321455252','Pratama Ketiga','IA','Admin',NULL,'$2y$10$M9XCWKPAVr/bqtj3OZuwlez4D15FsWz.KOcaBmexM/dhkcSPd6wua',NULL,NULL,'2021-02-04 10:36:10'),
(3,2,'Muhammad Fitri','fitri@gmail.com','19851014200805200','Pratama Kadua','VII G','Panitera',NULL,'$2y$10$9SzffCJsorZLLqBJN5SY7.QhdlAohhpiq9QCr7IWkis.xXKBcEh66',NULL,'2021-02-02 22:56:56','2021-02-03 03:38:47'),
(4,2,'H. Riduan, S.Ag.,','riduan@gmail.com','198510142008052002','Pratama Katiga','V A','Ketua PA Kotabaru',NULL,'$2y$10$bdSefgH4JImtKiJzM8/xteMmLQAptKm2qfBwU6oP5cpWI9Dizpcwq',NULL,'2021-02-02 23:00:07','2021-02-02 23:00:07'),
(5,2,'Feni Apriyanti, S.P','feni@gmail.com','522588522536','Pratama Keempat','II A','Panitera',NULL,'$2y$10$bVPqO1f8ALsdvEITXtTFcOGm8c8smZBE6hFtbuyaH3ZRRYbBpnCae',NULL,'2021-02-04 10:37:24','2021-02-07 10:35:21');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
