<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableDokumentDiklat extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('table_dokument_diklat', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('id_diklat');
            $table->foreign('id_diklat')->references('id')->on('table_diklat')->onDelete('cascade')->onUpdate('cascade');
            $table->string('path_gambar');
            $table->string('path_url');
            $table->string('nama_file');
            $table->string('slug');
            $table->string('extensi');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('table_dokument_diklat');
    }
}
