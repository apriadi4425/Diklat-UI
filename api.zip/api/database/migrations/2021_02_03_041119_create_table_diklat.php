<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableDiklat extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('table_diklat', function (Blueprint $table) {
            $table->id();
            $table->string('nama_diklat');
            $table->string('nomor_surat_tugas');
            $table->date('tanggal_surat_tugas');
            $table->string('perihal_undangan');
            $table->string('nomor_surat_undangan');
            $table->date('tanggal_surat_undangan');
            $table->string('tempat_acara');
            $table->date('tanggal_awal_acara');
            $table->date('tanggal_akhir_acara');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('table_diklat');
    }
}
