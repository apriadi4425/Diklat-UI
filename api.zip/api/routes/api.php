<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\DasboardController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\DiklatController;
use App\Http\Controllers\Api\SuratTugasController;
use App\Http\Controllers\Api\DokumentDiklatController;
use App\Http\Controllers\Api\SertifikatController;
use App\Http\Controllers\Api\KonfigController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware' => 'auth:sanctum'], function(){

    Route::get("dasboard",[DasboardController::class,'get']);
    Route::get("sedang-diklat",[DasboardController::class,'sedang_diklat']);

    Route::get("sertifikat",[SertifikatController::class,'get']);

    //All secure URL's
    Route::get("users",[UserController::class,'get_user']);
    Route::get("user-detail",[UserController::class,'detail']);
    Route::put("user-password",[UserController::class,'update_password']);
    Route::get("users2",[UserController::class,'get_user_by_tambah_peserta']);
    Route::post("user",[UserController::class,'insert']);
    Route::put("user",[UserController::class,'update']);

    Route::get("diklat",[DiklatController::class,'get_diklat']);
    Route::get("diklat-detil",[DiklatController::class,'get_by_id']);
    Route::post("diklat",[DiklatController::class,'insert']);
    Route::put("diklat",[DiklatController::class,'update']);
    Route::delete("diklat/{id}",[DiklatController::class,'hapus']);

    Route::post("surat-tugas",[SuratTugasController::class,'insert']);
    Route::put("surat-tugas",[SuratTugasController::class,'update']);
    Route::delete("surat-tugas/{id}",[SuratTugasController::class,'hapus']);


    Route::get("get-dokument",[DokumentDiklatController::class,'get_dokument']);
    Route::get("get-halaman",[DokumentDiklatController::class,'get_halaman_pdf']);
    Route::post("upload-surat-tugas",[DokumentDiklatController::class,'insert_surat_tugas']);
    Route::delete("upload-surat-tugas/{id}",[DokumentDiklatController::class,'hapus_surat_tugas']);
    Route::post("upload-dokumentasi",[DokumentDiklatController::class,'insert_dokumentasi_acara']);


    Route::get("konfig",[KonfigController::class,'get']);
    Route::put("konfig",[KonfigController::class,'ubah']);

  

});

Route::post("login",[UserController::class,'login']);


//	Route::middleware('auth:api')->get('/user', function (Request $request) {
//    	return $request->user();
//	});
