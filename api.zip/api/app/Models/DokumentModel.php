<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DokumentModel extends Model
{
    use HasFactory;
    protected $table = 'table_dokument_diklat';
    protected $fillabel = ['id_diklat','path_gambar','path_url','nama_file','slug','extensi','tipe'];
}
