<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ModelHalamanPdf extends Model
{
    use HasFactory;
    protected $table = 'table_halaman_pdf';
    protected $fillabel = ['id_dokument','path_image','nomor_urut','tipe'];
}
