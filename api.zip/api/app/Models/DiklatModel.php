<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DiklatModel extends Model
{
    use HasFactory;
    protected $table = 'table_diklat';
    protected $fillabel = ['nama_diklat','asal_surat_undangan','perihal_undangan','nomor_surat_undangan','tanggal_surat_undangan','tempat_acara','tanggal_awal_acara','tanggal_akhir_acara','slug'];

    public function surat_tugas(){
        return $this->hasMany(SuratTugasModdel::class, 'id_diklat')->with('peserta');
    }

    public function peserta(){
        return $this->hasMany(PesertaDiklatModel::class, 'id_diklat')->with('surat_tugas', 'diklat', 'user');
    }
}
