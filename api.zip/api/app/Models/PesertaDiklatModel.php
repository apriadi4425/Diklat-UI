<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PesertaDiklatModel extends Model
{
    use HasFactory;
    protected $table = 'table_peserta_diklat';
    protected $fillabel = ['id_diklat','id_surat_tugas','id_user'];

    public function diklat(){
        return $this->hasOne(DiklatModel::class,'id', 'id_diklat');
    }

    public function surat_tugas(){
        return $this->hasOne(SuratTugasModdel::class,'id', 'id_surat_tugas');
    }


    public function user(){
        return $this->hasOne(User::class,'id','id_user');
    }
}
