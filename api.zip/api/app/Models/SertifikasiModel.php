<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SertifikasiModel extends Model
{
    use HasFactory;
    protected $table = 'table_sertifikasi_peserta';
    protected $fillabel = ['id_dokument','id_user','id_diklat'];

    public function diklat(){
        return $this->hasOne(DiklatModel::class,'id', 'id_diklat');
    }

    public function dokument(){
        return $this->hasOne(DokumentModel::class,'id', 'id_dokument');
    }

    public function user(){
        return $this->hasOne(User::class,'id','id_user');
    }


}
