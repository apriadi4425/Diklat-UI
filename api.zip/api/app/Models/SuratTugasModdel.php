<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SuratTugasModdel extends Model
{
    use HasFactory;
    protected $table = 'table_surat_tugas';
    protected $fillabel = ['id_diklat','nomor_surat_tugas','tanggal_surat_tugas'];

    public function peserta(){
        return $this->hasMany(PesertaDiklatModel::class, 'id_surat_tugas')->with('user');
    }

    public function diklat(){
        return $this->hasOne(DiklatModel::class,'id','id_diklat');
    }
}
