<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SuratTugasModdel;
use App\Models\KonfigModel;

class CetakSuratTugas extends Controller
{
    function tanggal_indonesia($tanggal = null){
        if($tanggal == ''){
            return '';
        }elseif($tanggal == null){
            return '';
        }
        else{
            $bulan = array (
                1 =>   'Januari',
                'Februari',
                'Maret',
                'April',
                'Mei',
                'Juni',
                'Juli',
                'Agustus',
                'September',
                'Oktober',
                'November',
                'Desember'
            );
            $pecahkan = explode('-', $tanggal);
            return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
        }
    }

    function bulan($tanggal = null){
        if($tanggal == ''){
            return '';
        }elseif($tanggal == null){
            return '';
        }
        else{
            $bulan = array (
                1 =>   'Januari',
                'Februari',
                'Maret',
                'April',
                'Mei',
                'Juni',
                'Juli',
                'Agustus',
                'September',
                'Oktober',
                'November',
                'Desember'
            );
            $pecahkan = explode('-', $tanggal);
            return $bulan[ (int)$pecahkan[1] ];
        }
    }

    function cetak(Request $request){

        $id_surat_tugas = $request->id;
        $data_surat_tugas = SuratTugasModdel::with('peserta','diklat')->where('id', $id_surat_tugas)->first();
        $konfig = KonfigModel::first();


        $document_with_table = new \PhpOffice\PhpWord\PhpWord();

        $cellHCentered = array('size' => 11, 'name'=>'Arial');
        $styleCell =
            [
                'borderColor' =>'white',
                'borderSize' => 0,
                'valign'=>'top',
                'cellMarginBottom' => 0,
            ];

        $section = $document_with_table->addSection();
        $table = $section->addTable(array('align'=>'left'));
        $nomor = 1;
        $jumlah_data = count($data_surat_tugas->peserta);
        foreach($data_surat_tugas->peserta as $dp){
           
            if((int) $jumlah_data > 1){
                $table->addRow();
                $table->addCell(200,$styleCell)->addText('',$cellHCentered,array('align' => 'left', 'spaceAfter' => 0));
                $table->addCell(2500,$styleCell)->addText('Peserta '. $nomor++,$cellHCentered,array('align' => 'left', 'spaceAfter' => 0));
                $table->addCell(4000,$styleCell)->addText('',$cellHCentered,array('align' => 'left', 'spaceAfter' => 0));
                $table->addCell(500,$styleCell)->addText('',$cellHCentered,array('align' => 'left','spaceAfter' => 0));
                $table->addCell(8000,$styleCell)->addText('',$cellHCentered,array('align' => 'left','spaceAfter' => 0));
            }

            $table->addRow();
            $table->addCell(200,$styleCell)->addText('',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(2500,$styleCell)->addText('',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(4000,$styleCell)->addText('Nama',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(500,$styleCell)->addText(':',$cellHCentered,array('align' => 'left','spaceAfter' => 100));
            $table->addCell(8000,$styleCell)->addText($dp->user->name,$cellHCentered,array('align' => 'left','spaceAfter' => 100));

            $table->addRow();
            $table->addCell(200,$styleCell)->addText('',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(2500,$styleCell)->addText('',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(4000,$styleCell)->addText('NIP',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(500,$styleCell)->addText(':',$cellHCentered,array('align' => 'left','spaceAfter' => 100));
            $table->addCell(8000,$styleCell)->addText($dp->user->nip,$cellHCentered,array('align' => 'left','spaceAfter' => 100));

            $table->addRow();
            $table->addCell(200,$styleCell)->addText('',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(2500,$styleCell)->addText('',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(4000,$styleCell)->addText('Pangkat/ Gol. Ruang',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(500,$styleCell)->addText(':',$cellHCentered,array('align' => 'left','spaceAfter' => 100));
            $table->addCell(8000,$styleCell)->addText($dp->user->pangkat .' ('.$dp->user->golongan.')',$cellHCentered,array('align' => 'left','spaceAfter' => 0));

            $table->addRow();
            $table->addCell(200,$styleCell)->addText('',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(2500,$styleCell)->addText('',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(4000,$styleCell)->addText('Jabatan',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(500,$styleCell)->addText(':',$cellHCentered,array('align' => 'left','spaceAfter' => 100));
            $table->addCell(8000,$styleCell)->addText($dp->user->jabatan, $cellHCentered,array('align' => 'left','spaceAfter' => 100));

            $table->addRow();
            $table->addCell(200,$styleCell)->addText('',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(2500,$styleCell)->addText('',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(4000,$styleCell)->addText('Unit Kerja',$cellHCentered,array('align' => 'left', 'spaceAfter' => 100));
            $table->addCell(500,$styleCell)->addText(':',$cellHCentered,array('align' => 'left','spaceAfter' => 100));
            $table->addCell(8000,$styleCell)->addText('Pengadilan Tata Usaha Negara Banjarmasin', $cellHCentered,array('align' => 'left','spaceAfter' => 100));
        }




        $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($document_with_table, 'Word2007');
        $fullxml = $objWriter->getWriterPart('Document')->write();
        $tablexml = preg_replace('/^[\s\S]*(<w:tbl\b.*<\/w:tbl>).*/', '$1', $fullxml);
        $template_document = new \PhpOffice\PhpWord\TemplateProcessor(public_path('template/surat_tugas.docx'));

        $template_document->setValue('table', $tablexml);
        $template_document->setValue('nama_instansi', $konfig->nama_instansi);
        $template_document->setValue('alamat', $konfig->alamat);
        $template_document->setValue('kota', $konfig->kota);
        $template_document->setValue('kode_pos', $konfig->kode_pos);
        $template_document->setValue('telpon', $konfig->telpon);
        $template_document->setValue('fax', $konfig->fax);
        $template_document->setValue('email', $konfig->email);
        $template_document->setValue('website', $konfig->website);

        $template_document->setValue('nomor_surat_tugas', $data_surat_tugas->nomor_surat_tugas);
        $template_document->setValue('asal_surat_undangan', $data_surat_tugas->diklat->asal_surat_undangan);
        $template_document->setValue('nomor_surat_undangan', $data_surat_tugas->diklat->nomor_surat_undangan);
        $template_document->setValue('tanggal_surat_undangan', $this->tanggal_indonesia($data_surat_tugas->diklat->tanggal_surat_undangan));
        $template_document->setValue('perihal_undangan', $data_surat_tugas->diklat->perihal_undangan);
        $template_document->setValue('nama_diklat', $data_surat_tugas->diklat->nama_diklat);

        $template_document->setValue('tempat_diklat', $data_surat_tugas->diklat->tempat_acara);

        $tgl_awal_explode = explode('-', $data_surat_tugas->diklat->tanggal_awal_acara);
        $tgl_akhir_explode = explode('-', $data_surat_tugas->diklat->tanggal_akhir_acara);

        $tgl_awal_bulan = $tgl_awal_explode[1].'-'.$tgl_awal_explode[2];
        $tgl_akhir_bulan = $tgl_akhir_explode[1].'-'.$tgl_akhir_explode[2];

        if($tgl_awal_bulan == $tgl_akhir_bulan){
            $tanggalnya = $this->tanggal_indonesia($data_surat_tugas->diklat->tanggal_awal_acara);
        }else{
            if($tgl_awal_explode[1] == $tgl_akhir_explode[1]){
                $tanggalnya = $tgl_awal_explode[2].'-'.$tgl_akhir_explode[2].' '.$this->bulan($data_surat_tugas->diklat->tanggal_awal_acara) . ' '. $tgl_akhir_explode[0];
            }else{
                $tanggalnya = $this->tanggal_indonesia($data_surat_tugas->diklat->tanggal_awal_acara) .' - '. $this->tanggal_indonesia($data_surat_tugas->diklat->tanggal_akhir_acara);
            }
        }

        $template_document->setValue('tanggal_diklat', $tanggalnya);
        $template_document->setValue('tanggal_surat_tugas', $this->tanggal_indonesia($data_surat_tugas->tanggal_surat_tugas));
        $template_document->setValue('nama_ketua', $konfig->nama_ketua);
        $template_document->setValue('nip_ketua', $konfig->nip_ketua);

        $temp_filename = 'surat_tugas.docx';
        $template_document->saveAs($temp_filename);
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename='.$temp_filename);
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($temp_filename));
        flush();
        readfile($temp_filename);
        unlink($temp_filename);
        exit;
    }
}
