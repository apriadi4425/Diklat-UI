<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Validator;

class UserController extends Controller
{
    function login(Request $request)
    {
        $user= User::where('email', $request->email)->first();
        // print_r($data);
            if (!$user || !Hash::check($request->password, $user->password)) {
                return response([
                    'message' => ['These credentials do not match our records.']
                ], 401);
            }
        
             $token = $user->createToken('my-app-token')->plainTextToken;
        
            $response = [
                'user' => $user,
                'token' => $token
            ];
        
             return response($response, 201);
    }

    function get_user(){
        return User::get();
    }

    function get_user_by_tambah_peserta(){
        $data = User::get();
        $new_array = array();
        foreach($data as $dt){
            $new_array[] = $dt->name;
        }

        return response()->json($new_array, 200);
    }


    function insert(Request $request){
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|unique:users',
        ],
        [   
            'email.unique' => 'Email Telah digunakan Oleh User Lain',
        ]);

        if ($validator->fails()) {
            return response()->json(['error'=>$validator->errors()], 400);
        }


        $data = new User;
        $data->name = $request->name;
        $data->email = $request->email;

        $data->nip = $request->nip;
        $data->jabatan = $request->jabatan;
        $data->pangkat = $request->pangkat;
        $data->golongan = $request->golongan;

        $data->otoritas = 2;
        $data->password =  Hash::make($request->password);
        $eksekusi = $data->save();

        if($eksekusi){
            return response('sukses', 200);
        }else{
            return response('error', 500);
        }
    }

    public function update(Request $request){

        $update = User::find($request->id);
        $update->name = $request->name;
        $update->email = $request->email;
        $update->nip = $request->nip;
        $update->jabatan = $request->jabatan;
        $update->pangkat = $request->pangkat;
        $update->golongan = $request->golongan;
        $eksekusi = $update->update();

        if($eksekusi){
            return response('sukses', 200);
        }else{
            return response('error', 500);
        }
    }

    function update_password(Request $request){
        $update = User::find($request->id);
        $update->password =  Hash::make($request->password);
        $update->update();
        return response()->json('sukses', 200);
    }

    public function detail(){
        $auth = Auth::user();
        return response()->json($auth, 200);
    }
}
