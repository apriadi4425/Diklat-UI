<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SertifikasiModel;
use Illuminate\Support\Facades\Auth;

class SertifikatController extends Controller
{
    function tanggal_indonesia($tanggal = null){
        if($tanggal == ''){
            return '';
        }elseif($tanggal == null){
            return '';
        }
        else{
            $bulan = array (
                1 =>   'Januari',
                'Februari',
                'Maret',
                'April',
                'Mei',
                'Juni',
                'Juli',
                'Agustus',
                'September',
                'Oktober',
                'November',
                'Desember'
            );
            $pecahkan = explode('-', $tanggal);
            return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
        }
    }

    function bulan($tanggal = null){
        if($tanggal == ''){
            return '';
        }elseif($tanggal == null){
            return '';
        }
        else{
            $bulan = array (
                1 =>   'Januari',
                'Februari',
                'Maret',
                'April',
                'Mei',
                'Juni',
                'Juli',
                'Agustus',
                'September',
                'Oktober',
                'November',
                'Desember'
            );
            $pecahkan = explode('-', $tanggal);
            return $bulan[ (int)$pecahkan[1] ];
        }
    }

    public function get(){
        $auth = Auth::user();
        if($auth->otoritas == 1){
            $sertifikat =  SertifikasiModel::with('dokument', 'diklat','user')->get();
        }else{
            $sertifikat =  SertifikasiModel::with('dokument', 'diklat','user')->where('id_user', $auth->id)->get();
        }
        $new_array = array();
        $no = 1;

        foreach($sertifikat as $srt){

            $tgl_awal_explode = explode('-', $srt->diklat->tanggal_awal_acara);
                $tgl_akhir_explode = explode('-', $srt->diklat->tanggal_akhir_acara);
        
                $tgl_awal_bulan = $tgl_awal_explode[1].'-'.$tgl_awal_explode[2];
                $tgl_akhir_bulan = $tgl_akhir_explode[1].'-'.$tgl_akhir_explode[2];
        
                if($tgl_awal_bulan == $tgl_akhir_bulan){
                    $tanggalnya = $this->tanggal_indonesia($srt->diklat->tanggal_awal_acara);
                }else{
                    if($tgl_awal_explode[1] == $tgl_akhir_explode[1]){
                        $tanggalnya = $tgl_awal_explode[2].'-'.$tgl_akhir_explode[2].' '.$this->bulan($srt->diklat->tanggal_awal_acara) . ' '. $tgl_akhir_explode[0];
                    }else{
                        $tanggalnya = $this->tanggal_indonesia($srt->diklat->tanggal_awal_acara) .' - '. $this->tanggal_indonesia($srt->diklat->tanggal_akhir_acara);
                    }
                }

            $new_array[] = array(
                'nama' => $srt->user->name,
                'nama_diklat' => $srt->diklat->nama_diklat,
                'tanggal_diklat' => $tanggalnya,
                'sertifikat' => $srt->dokument->id,
                'path' => url('dokument/sertifikat/'.$srt->dokument->path_gambar),
                'url' => url('dokument/sertifikat/'.$srt->dokument->path_url)
            );
        }

        return response()->json($new_array, 200);

    }

}
