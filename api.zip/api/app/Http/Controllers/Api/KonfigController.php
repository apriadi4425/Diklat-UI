<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\KonfigModel;

class KonfigController extends Controller
{
    function get(){
        return KonfigModel::where('id', 1)->first();
    }

    public function ubah(Request $request){
        $update = KonfigModel::find(1);
        $update->nama_aplikasi = $request->nama_aplikasi;
        $update->singkatan_aplikasi = $request->singkatan_aplikasi;
        $update->nama_instansi = $request->nama_instansi;
        $update->singkatan_instansi = $request->singkatan_instansi;
        $update->kota = $request->kota;
        $update->nama_ketua = $request->nama_ketua;
        $update->nip_ketua = $request->nip_ketua;

        $update->email = $request->email;
        $update->alamat = $request->alamat;
        $update->telpon = $request->telpon;
        $update->website = $request->website;
        $update->fax = $request->fax;
        $update->kode_pos = $request->kode_pos;
        $update->update();

        return response()->json('sukses', 200);
    }
}