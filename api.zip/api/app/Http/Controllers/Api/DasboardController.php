<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DiklatModel;
use App\Models\PesertaDiklatModel;
use App\Models\DokumentModel;
use App\Models\User;

class DasboardController extends Controller
{
    function tanggal_indonesia($tanggal = null){
        if($tanggal == ''){
            return '';
        }elseif($tanggal == null){
            return '';
        }
        else{
            $bulan = array (
                1 =>   'Januari',
                'Februari',
                'Maret',
                'April',
                'Mei',
                'Juni',
                'Juli',
                'Agustus',
                'September',
                'Oktober',
                'November',
                'Desember'
            );
            $pecahkan = explode('-', $tanggal);
            return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
        }
    }

    function bulan($tanggal = null){
        if($tanggal == ''){
            return '';
        }elseif($tanggal == null){
            return '';
        }
        else{
            $bulan = array (
                1 =>   'Januari',
                'Februari',
                'Maret',
                'April',
                'Mei',
                'Juni',
                'Juli',
                'Agustus',
                'September',
                'Oktober',
                'November',
                'Desember'
            );
            $pecahkan = explode('-', $tanggal);
            return $bulan[ (int)$pecahkan[1] ];
        }
    }

    public function get(){
        $diklat = DiklatModel::count();
        $sedang_diklat_hari_ini = DiklatModel::where('tanggal_awal_acara','<', date('Y-m-d'))->where('tanggal_akhir_acara', '>', date('Y-m-d'))->get();
        
        $jumlah_peserta_sedang_diklat = 0;
        foreach($sedang_diklat_hari_ini as $sdhi){
            $peserta_diklat = PesertaDiklatModel::where('id_diklat', $sdhi->id)->count();
            $jumlah_peserta_sedang_diklat += $peserta_diklat;
        }

        $jumlahsertifikat = DokumentModel::where('tipe', 3)->count();
        $jumlah_pegawai = User::where('nip', '!=', null)->count();

        $data = array(
            'jumlah_diklat' => $diklat,
            'sedang_diklat' => $jumlah_peserta_sedang_diklat,
            'jumlah_sertifikat' => $jumlahsertifikat,
            'jumlah_pegawai' => $jumlah_pegawai
        );

        return response($data, 200);
    }


    public function sedang_diklat(){
        $sedang_diklat_hari_ini = DiklatModel::with('peserta')->where('tanggal_awal_acara','<', date('Y-m-d'))->where('tanggal_akhir_acara', '>', date('Y-m-d'))->get();
        
        $no = 1;
        $new_array = array();
        foreach($sedang_diklat_hari_ini as $sdhi){
            
            $peserta = $sdhi->peserta;
            foreach($peserta as $p){

                $tgl_awal_explode = explode('-', $p->diklat->tanggal_awal_acara);
                $tgl_akhir_explode = explode('-', $p->diklat->tanggal_akhir_acara);
        
                $tgl_awal_bulan = $tgl_awal_explode[1].'-'.$tgl_awal_explode[2];
                $tgl_akhir_bulan = $tgl_akhir_explode[1].'-'.$tgl_akhir_explode[2];
        
                if($tgl_awal_bulan == $tgl_akhir_bulan){
                    $tanggalnya = $this->tanggal_indonesia($p->diklat->tanggal_awal_acara);
                }else{
                    if($tgl_awal_explode[1] == $tgl_akhir_explode[1]){
                        $tanggalnya = $tgl_awal_explode[2].'-'.$tgl_akhir_explode[2].' '.$this->bulan($p->diklat->tanggal_awal_acara) . ' '. $tgl_akhir_explode[0];
                    }else{
                        $tanggalnya = $this->tanggal_indonesia($p->diklat->tanggal_awal_acara) .' - '. $this->tanggal_indonesia($p->diklat->tanggal_akhir_acara);
                    }
                }

                $nomor = $no++;
                $new_array[] = array(
                    'no' => $nomor,
                    'nama_peserta' => $p->user->name,
                    'nama_diklat' =>$p->diklat->nama_diklat,
                    'tempat_diklat' =>$p->diklat->tempat_acara,
                    'tanggal_diklat' => $tanggalnya,
                );
            }
        }

        return $new_array;
    }
}
