<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DiklatModel;

class DiklatController extends Controller
{
    public function get_diklat(){
        return DiklatModel::orderBy('id','desc')->get();
    }

    public function get_by_id(Request $request){
        $data = DiklatModel::with('surat_tugas')->where('slug', $request->slug)->first();
        return $data;
    }

    public function insert(Request $request){
        $data = new DiklatModel;
        $data->nama_diklat = $request->nama_diklat;
        $data->asal_surat_undangan = $request->asal_surat_undangan;
        $data->perihal_undangan = $request->perihal_undangan;
        $data->nomor_surat_undangan = $request->nomor_surat_undangan;
        $data->tanggal_surat_undangan = $request->tanggal_surat_undangan;
        $data->tempat_acara = $request->tempat_acara;
        $data->tanggal_awal_acara = $request->tanggal_awal_acara;
        $data->tanggal_akhir_acara = $request->tanggal_akhir_acara;
        $data->slug = encrypt($request->nomor_surat_undangan.date('Y-m-d H:i:s'));
        $eksekusi = $data->save();
        if($eksekusi){
            return response()->json('sukses', 200);
        }else{
            return response()->json('error', 500);
        }
    }

    public function update(Request $request){

        $data = DiklatModel::find($request->id);
        $data->nama_diklat = $request->nama_diklat;
        $data->asal_surat_undangan = $request->asal_surat_undangan;
        $data->perihal_undangan = $request->perihal_undangan;
        $data->nomor_surat_undangan = $request->nomor_surat_undangan;
        $data->tanggal_surat_undangan = $request->tanggal_surat_undangan;
        $data->tempat_acara = $request->tempat_acara;
        $data->tanggal_awal_acara = $request->tanggal_awal_acara;
        $data->tanggal_akhir_acara = $request->tanggal_akhir_acara;
        $eksekusi = $data->update();
        if($eksekusi){
            return response()->json('sukses', 200);
        }else{
            return response()->json('error', 500);
        }
    }

    public function hapus($id){
        $diklat = DiklatModel::find($id);
        $diklat->delete();
        return response()->json('sukses', 200);
    }
}