<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SuratTugasModdel;
use App\Models\PesertaDiklatModel;
use App\Models\User;

class SuratTugasController extends Controller
{
    function insert(Request $request){
        $id_diklat = $request->id_diklat;
        $nomor_surat_tugas = $request->nomor_surat_tugas;
        $tanggal_surat_tugas = $request->tanggal_surat_tugas;
        $peserta = $request->peserta;

        $surat_tugas = new SuratTugasModdel;
        $surat_tugas->id_diklat = $id_diklat;
        $surat_tugas->nomor_surat_tugas = $nomor_surat_tugas;
        $surat_tugas->tanggal_surat_tugas = $tanggal_surat_tugas;
        $eksekusi_surat_tugas = $surat_tugas->save();
        if($eksekusi_surat_tugas){
            foreach($peserta as $p){
                $user = User::where('name', $p)->first();
                $peserta = new PesertaDiklatModel;
                $peserta->id_diklat = $id_diklat;
                $peserta->id_surat_tugas = $surat_tugas->id;
                $peserta->id_user = $user->id;
                $peserta->save();
            }
            return response()->json('sukses', 200);
        }else{
            return response()->json('error', 500);
        }
    }


    public function update(Request $request){
        $peserta = $request->peserta;
        $id_diklat = $request->id_diklat;

        $surat_tugas = SuratTugasModdel::find($request->id);
        $surat_tugas->nomor_surat_tugas =$request->nomor_surat_tugas;
        $surat_tugas->tanggal_surat_tugas = $request->tanggal_surat_tugas;
        $eksekusi_surat_tugas = $surat_tugas->update();
        
        if($eksekusi_surat_tugas){

            $data_peserta = PesertaDiklatModel::where(['id_surat_tugas' => $request->id])->get();
            foreach($data_peserta as $dp){
                $delete = PesertaDiklatModel::find($dp->id);
                $delete->delete();
            }

            foreach($peserta as $p){
                $user = User::where('name', $p)->first();
                $peserta = new PesertaDiklatModel;
                $peserta->id_diklat = $id_diklat;
                $peserta->id_surat_tugas = $surat_tugas->id;
                $peserta->id_user = $user->id;
                $peserta->save();
            }
            return response()->json('sukses', 200);
        }else{
            return response()->json('error', 500);
        }


    }

    public function hapus($id){
        $surat_tugas = SuratTugasModdel::find($id);
        $surat_tugas->delete();
        return response()->json('sukses', 200);
    }
}
