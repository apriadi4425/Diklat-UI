<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Spatie\PdfToImage\Pdf;
use App\Models\DokumentModel;
use App\Models\ModelHalamanPdf;
use App\Models\User;
use App\Models\SertifikasiModel;
use File;



class DokumentDiklatController extends Controller
{

    public function get_dokument(Request $request){
        return DokumentModel::where(['tipe' => $request->tipe, 'id_diklat' => $request->id])->get();
    }


    public function get_halaman_pdf(Request $request){
        $data = ModelHalamanPdf::where(['id_dokument' => $request->id_dokument])->orderBy('nomor_urut','asc')->get();
        $new_array = array();
        foreach($data as $dt){
            if($dt->tipe == 1){
                $new_array[] = url('dokument/surat-tugas/'.$dt->path_image);
            }else{
                $new_array[] = url('dokument/sertifikat/'.$dt->path_image);
            }
        }

        return response()->json($new_array, 200);
    }


    public function insert_surat_tugas(Request $request){

        $original_name1 = $request->file->getClientOriginalName();
        $original_name = $request->id_diklat.'-'.$request->file->getClientOriginalName();
        $slug = str_replace(' ','-', $original_name);
        $slug2 = str_replace('.pdf','', $slug);
        $slug3 = str_replace('.','', $slug2);

        if($request->tipe == 1){
            $pathnya = 'dokument/surat-tugas';
        }else{
            $pathnya = 'dokument/sertifikat';
        }

        
        $nama_file = $slug2.'-'.time().'.'.$request->file->extension();
        $eksekusi = $request->file->storeAs($pathnya, $nama_file);

        
        

        if($eksekusi){
            
            $path = public_path($pathnya.'/'.$request->id_diklat);
            File::isDirectory($path) or File::makeDirectory($path, 0777, true, true);

            $pdf = new Pdf(public_path($pathnya.'/'.$nama_file));
            $jumlah_halaman = $pdf->getNumberOfPages();
            for($i = 1; $i <= $jumlah_halaman; $i++){
                $eksekusi2 = $pdf->setPage($i)->setOutputFormat('png')->saveImage(public_path($pathnya.'/'.$request->id_diklat.'/'.$i.'-'.$slug3.'.png'));
            }
           
            $dokument = new DokumentModel;
            $dokument->id_diklat = $request->id_diklat;
            $dokument->tipe = $request->tipe;
            $dokument->path_gambar = $request->id_diklat.'/1-'.$slug3.'.png';
            $dokument->path_url = $nama_file;
            $dokument->nama_file = $original_name1;
            $dokument->slug =  $slug;
            $dokument->extensi = $request->file->extension();
            $eksekusi3 = $dokument->save();
            if($eksekusi3){
                if($request->tipe == 3){
                    $peserta = json_decode($request->peserta, TRUE);
                    
                    if(count($peserta) > 0){
                        foreach($peserta as $p){
                            $user = User::where('name', $p)->first();
                            $sertifikasi = new SertifikasiModel;
                            $sertifikasi->id_diklat = $request->id_diklat;
                            $sertifikasi->id_dokument = $dokument->id;
                            $sertifikasi->id_user = $user->id;
                            $sertifikasi->save();
                        }
                    }
                    
                }
                for($i = 1; $i <= $jumlah_halaman; $i++){
                    $halaman = new ModelHalamanPdf;
                    $halaman->id_dokument = $dokument->id;
                    $halaman->tipe = $request->tipe;
                    $halaman->path_image = $request->id_diklat.'/'.$i.'-'.$slug3.'.png';
                    $halaman->nomor_urut = $i;
                    $halaman->save();
                }
            }
            return response()->json($jumlah_halaman, 200);

        }
    }

    public function hapus_surat_tugas($id){
        $hapus = DokumentModel::find($id);
        $hapus->delete();
        return response()->json('sukses', 200);
    }


    public function insert_dokumentasi_acara(Request $request){

        $original_name1 = $request->file->getClientOriginalName();
        $original_name = $request->id_diklat.'-'.$request->file->getClientOriginalName();
        $slug = str_replace(' ','-', $original_name);

        
        $nama_file = $slug.'-'.time().'.'.$request->file->extension();
        $eksekusi = $request->file->storeAs('dokument/dokumentasi', $nama_file);
        

        if($eksekusi){
            
            $dokument = new DokumentModel;
            $dokument->id_diklat = $request->id_diklat;
            $dokument->tipe = 2;
            $dokument->path_gambar = '';
            $dokument->path_url = $nama_file;
            $dokument->nama_file = $original_name1;
            $dokument->slug =  $slug;
            $dokument->extensi = $request->file->extension();
            $eksekusi3 = $dokument->save();

           
            return response()->json('sukses', 200);

        }
    }
}
